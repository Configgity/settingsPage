package za.ac.opsc.settingspagedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bNV;

    private Button changeSet;
    private Button helpBtn;
    private Button issueBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        changeSet= (Button) findViewById(R.id.btn_changeSet);
        changeSet.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openChangeSettingsPage();
            }
        });
        helpBtn = (Button)  findViewById(R.id.btn_help);
        helpBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openHelpPage();
            }
        });
       issueBtn = (Button) findViewById(R.id.btn_repIssue);
       issueBtn.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v){
             openReportIssue();
           }
       });




    }
    public void openChangeSettingsPage(){
        Intent intent =  new Intent(this, changeSettingsPage.class);
        startActivity(intent);
    }
    public void openHelpPage(){
        Intent intent = new Intent(this, helpPage.class);
        startActivity(intent);
    }
    public void openReportIssue(){
        Intent intent = new Intent(this, reportIssue.class);
        startActivity(intent);
    }
}

